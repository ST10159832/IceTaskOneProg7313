package vcmsa.projects.calculatorapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Get references to UI components
        val etInput = findViewById<EditText>(R.id.etInput)
        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSubtract = findViewById<Button>(R.id.btnSubtract)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btnDivide = findViewById<Button>(R.id.btnDivide)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        // Click listeners for each button
        btnAdd.setOnClickListener { performOperation(etInput, tvResult, "+") }
        btnSubtract.setOnClickListener { performOperation(etInput, tvResult, "-") }
        btnMultiply.setOnClickListener { performOperation(etInput, tvResult, "*") }
        btnDivide.setOnClickListener { performOperation(etInput, tvResult, "/") }
    }

    // Function to perform calculations
    private fun performOperation(etInput: EditText, tvResult: TextView, operator: String) {
        val inputText = etInput.text.toString()

        // Split input by space to get two numbers
        val numbers = inputText.split(" ")

        if (numbers.size == 2) {
            val num1 = numbers[0].toDoubleOrNull()
            val num2 = numbers[1].toDoubleOrNull()

            if (num1 != null && num2 != null) {
                val result = when (operator) {
                    "+" -> num1 + num2
                    "-" -> num1 - num2
                    "*" -> num1 * num2
                    "/" -> if (num2 != 0.0) num1 / num2 else "Cannot divide by zero"
                    else -> "Error"
                }
                tvResult.text = "Result: $result"
            } else {
                tvResult.text = "Invalid input"
            }
        } else {
            tvResult.text = "Enter two numbers separated by space"
        }
    }
}
